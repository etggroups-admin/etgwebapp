/* =============================================
   ETG GROUPS — Support Tickets Module
   ============================================= */

function renderTickets() {
  const tickets = getData('etg_tickets') || [];
  const isAdmin = currentUser && currentUser.role === 'admin';

  // Build ticket table
  let ticketRows = '';
  const displayTickets = isAdmin ? tickets : tickets.filter(t => t.createdBy === currentUser.username);

  if (displayTickets.length > 0) {
    ticketRows = displayTickets.map(t => {
      const statusBadge = t.status === 'Open' ? 'badge-danger' :
                          t.status === 'In Progress' ? 'badge-warning' :
                          t.status === 'Resolved' ? 'badge-success' : 'badge-info';
      return `<tr>
        <td><span class="badge badge-gold">${t.ticketId}</span></td>
        <td>${t.name}</td>
        <td>${t.empId}</td>
        <td>${t.subject}</td>
        <td><span class="badge ${statusBadge}">${t.status}</span></td>
        <td>${t.date}</td>
        <td>
          <button class="btn-icon" onclick="viewTicket('${t.ticketId}')" title="View"><i class="fa-solid fa-eye"></i></button>
          ${isAdmin ? `<button class="btn-icon" onclick="updateTicketStatus('${t.ticketId}')" title="Update Status"><i class="fa-solid fa-pen"></i></button>
          <button class="btn-icon" onclick="deleteTicket('${t.ticketId}')" title="Delete"><i class="fa-solid fa-trash"></i></button>` : ''}
        </td>
      </tr>`;
    }).join('');
    ticketRows = `<div class="table-container"><table>
      <thead><tr><th>Ticket ID</th><th>Name</th><th>Emp ID</th><th>Subject</th><th>Status</th><th>Date</th><th>Actions</th></tr></thead>
      <tbody>${ticketRows}</tbody></table></div>`;
  } else {
    ticketRows = '<div class="no-data"><i class="fa-solid fa-ticket"></i><p>No tickets found</p></div>';
  }

  // Stats
  const openCount = displayTickets.filter(t => t.status === 'Open').length;
  const inProgressCount = displayTickets.filter(t => t.status === 'In Progress').length;
  const resolvedCount = displayTickets.filter(t => t.status === 'Resolved').length;

  document.getElementById('ticketsContent').innerHTML = `
    <div class="stats-grid">
      <div class="stat-card">
        <div class="stat-icon red"><i class="fa-solid fa-circle-exclamation"></i></div>
        <div class="stat-info"><h4>${openCount}</h4><p>Open Tickets</p></div>
      </div>
      <div class="stat-card">
        <div class="stat-icon gold"><i class="fa-solid fa-spinner"></i></div>
        <div class="stat-info"><h4>${inProgressCount}</h4><p>In Progress</p></div>
      </div>
      <div class="stat-card">
        <div class="stat-icon green"><i class="fa-solid fa-check-circle"></i></div>
        <div class="stat-info"><h4>${resolvedCount}</h4><p>Resolved</p></div>
      </div>
      <div class="stat-card">
        <div class="stat-icon blue"><i class="fa-solid fa-layer-group"></i></div>
        <div class="stat-info"><h4>${displayTickets.length}</h4><p>Total Tickets</p></div>
      </div>
    </div>

    <div class="card mb-24">
      <div class="card-header">
        <h3><i class="fa-solid fa-ticket"></i> ${isAdmin ? 'All Tickets' : 'My Tickets'}</h3>
        <button class="btn btn-gold btn-sm" onclick="openCreateTicketModal()"><i class="fa-solid fa-plus"></i> Raise Ticket</button>
      </div>
      ${ticketRows}
    </div>`;
}

function openCreateTicketModal() {
  // Auto-detect system IP
  fetchSystemIP().then(ip => {
    openModal('<i class="fa-solid fa-ticket"></i> Raise Support Ticket', `
      <div class="form-grid">
        <div class="form-group-app"><label>Your Name *</label><input type="text" id="tkName" value="${currentUser.fullName}" placeholder="Enter your name"></div>
        <div class="form-group-app"><label>Email ID *</label><input type="email" id="tkEmail" placeholder="Enter your email"></div>
        <div class="form-group-app"><label>Employee ID *</label><input type="text" id="tkEmpId" placeholder="Enter your Emp ID"></div>
        <div class="form-group-app"><label>System IP</label><input type="text" id="tkIP" value="${ip}" readonly style="opacity:0.7;cursor:not-allowed;"></div>
      </div>
      <div class="form-group-app mt-16"><label>Subject *</label><input type="text" id="tkSubject" placeholder="Brief summary of the issue"></div>
      <div class="form-group-app"><label>Issue Description *</label><textarea id="tkMessage" rows="5" placeholder="Describe your issue in detail..." style="resize:vertical;"></textarea></div>
      <div class="form-group-app"><label>Priority</label><select id="tkPriority">
        <option value="Low">Low</option>
        <option value="Medium" selected>Medium</option>
        <option value="High">High</option>
        <option value="Critical">Critical</option>
      </select></div>
      <button class="btn btn-gold w-full mt-16" onclick="submitTicket()"><i class="fa-solid fa-paper-plane"></i> Submit Ticket</button>
    `);
  });
}

async function fetchSystemIP() {
  try {
    const res = await fetch('https://api.ipify.org?format=json');
    const data = await res.json();
    return data.ip;
  } catch {
    return 'Unable to detect';
  }
}

function submitTicket() {
  const name = document.getElementById('tkName').value.trim();
  const email = document.getElementById('tkEmail').value.trim();
  const empId = document.getElementById('tkEmpId').value.trim();
  const subject = document.getElementById('tkSubject').value.trim();
  const message = document.getElementById('tkMessage').value.trim();
  const ip = document.getElementById('tkIP').value.trim();
  const priority = document.getElementById('tkPriority').value;

  if (!name || !email || !empId || !subject || !message) {
    showToast('Please fill all required fields', 'error');
    return;
  }

  const tickets = getData('etg_tickets') || [];
  const ticketCount = tickets.length + 1;
  const ticketId = 'TKT-' + String(ticketCount).padStart(4, '0');

  const ticket = {
    ticketId,
    name,
    email,
    empId,
    subject,
    message,
    systemIP: ip,
    priority,
    status: 'Open',
    createdBy: currentUser.username,
    date: new Date().toISOString().split('T')[0],
    time: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }),
    adminReply: ''
  };

  tickets.push(ticket);
  setData('etg_tickets', tickets);
  // Notify admin
  addNotification(`🎫 New ticket <strong>${ticketId}</strong> raised by <strong>${name}</strong> — ${subject}`, 'admin', 'fa-ticket');
  closeModal();
  renderTickets();
  showToast(`Ticket raised successfully! ID: ${ticketId}`, 'success');
}

function viewTicket(ticketId) {
  const ticket = (getData('etg_tickets') || []).find(t => t.ticketId === ticketId);
  if (!ticket) return;

  const isAdmin = currentUser && currentUser.role === 'admin';
  const priorityColor = ticket.priority === 'Critical' ? 'var(--danger)' :
                         ticket.priority === 'High' ? 'var(--warning)' :
                         ticket.priority === 'Medium' ? 'var(--info)' : 'var(--success)';

  openModal(`<i class="fa-solid fa-ticket"></i> ${ticket.ticketId} — ${ticket.subject}`, `
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:20px;">
      <div><p style="font-size:0.72rem;color:var(--text-muted);text-transform:uppercase;">Name</p><p style="font-weight:600;">${ticket.name}</p></div>
      <div><p style="font-size:0.72rem;color:var(--text-muted);text-transform:uppercase;">Employee ID</p><p style="font-weight:600;">${ticket.empId}</p></div>
      <div><p style="font-size:0.72rem;color:var(--text-muted);text-transform:uppercase;">Email</p><p style="font-weight:600;">${ticket.email}</p></div>
      <div><p style="font-size:0.72rem;color:var(--text-muted);text-transform:uppercase;">System IP</p><p style="font-weight:600;">${ticket.systemIP}</p></div>
      <div><p style="font-size:0.72rem;color:var(--text-muted);text-transform:uppercase;">Date</p><p style="font-weight:600;">${ticket.date} ${ticket.time}</p></div>
      <div><p style="font-size:0.72rem;color:var(--text-muted);text-transform:uppercase;">Priority</p><p style="font-weight:600;color:${priorityColor};">${ticket.priority}</p></div>
      <div><p style="font-size:0.72rem;color:var(--text-muted);text-transform:uppercase;">Status</p><p style="font-weight:600;">${ticket.status}</p></div>
    </div>
    <div style="background:var(--bg-glass);padding:16px;border-radius:var(--radius-sm);border:1px solid var(--border-glass);margin-bottom:16px;">
      <p style="font-size:0.72rem;color:var(--text-muted);text-transform:uppercase;margin-bottom:8px;">Issue Description</p>
      <p style="font-size:0.9rem;line-height:1.7;white-space:pre-wrap;">${ticket.message}</p>
    </div>
    ${ticket.adminReply ? `<div style="background:rgba(31,184,100,0.06);padding:16px;border-radius:var(--radius-sm);border:1px solid rgba(31,184,100,0.2);">
      <p style="font-size:0.72rem;color:var(--success);text-transform:uppercase;margin-bottom:8px;"><i class="fa-solid fa-reply"></i> Admin Reply</p>
      <p style="font-size:0.9rem;line-height:1.7;white-space:pre-wrap;">${ticket.adminReply}</p>
    </div>` : ''}
    ${isAdmin ? `<div class="form-group-app mt-16"><label>Admin Reply</label><textarea id="tkAdminReply" rows="3" placeholder="Reply to this ticket...">${ticket.adminReply || ''}</textarea></div>
    <button class="btn btn-gold w-full" onclick="saveAdminReply('${ticketId}')"><i class="fa-solid fa-reply"></i> Save Reply</button>` : ''}
  `);
}

function saveAdminReply(ticketId) {
  const reply = document.getElementById('tkAdminReply').value.trim();
  const tickets = getData('etg_tickets');
  const ticket = tickets.find(t => t.ticketId === ticketId);
  if (ticket) {
    ticket.adminReply = reply;
    setData('etg_tickets', tickets);
    // Notify the specific staff user about admin reply
    addNotification(`💬 Admin replied to your ticket <strong>${ticketId}</strong>.`, null, 'fa-reply', ticket.createdBy);
    closeModal();
    renderTickets();
    showToast('Reply saved', 'success');
  }
}

function updateTicketStatus(ticketId) {
  if (!currentUser || currentUser.role !== 'admin') { showToast('Admin access required', 'error'); return; }
  const tickets = getData('etg_tickets');
  const ticket = tickets.find(t => t.ticketId === ticketId);
  if (!ticket) return;

  openModal('<i class="fa-solid fa-pen"></i> Update Ticket Status — ' + ticketId, `
    <div class="form-group-app"><label>Subject</label><input type="text" value="${ticket.subject}" disabled style="opacity:0.6;"></div>
    <div class="form-group-app"><label>Raised By</label><input type="text" value="${ticket.name} (${ticket.empId})" disabled style="opacity:0.6;"></div>
    <div class="form-group-app"><label>Current Status</label><select id="tkNewStatus">
      ${['Open', 'In Progress', 'Resolved', 'Closed'].map(s => `<option ${ticket.status === s ? 'selected' : ''}>${s}</option>`).join('')}
    </select></div>
    <button class="btn btn-gold w-full mt-16" onclick="saveTicketStatus('${ticketId}')"><i class="fa-solid fa-save"></i> Update Status</button>
  `);
}

function saveTicketStatus(ticketId) {
  const tickets = getData('etg_tickets');
  const ticket = tickets.find(t => t.ticketId === ticketId);
  if (ticket) {
    const oldStatus = ticket.status;
    ticket.status = document.getElementById('tkNewStatus').value;
    setData('etg_tickets', tickets);
    // Notify the specific ticket creator when status changes
    if ((ticket.status === 'Resolved' || ticket.status === 'Closed') && oldStatus !== ticket.status) {
      addNotification(`✅ Your ticket <strong>${ticketId}</strong> has been <strong>${ticket.status}</strong> by admin.`, null, 'fa-check-circle', ticket.createdBy);
    } else if (ticket.status === 'In Progress' && oldStatus !== ticket.status) {
      addNotification(`🔄 Ticket <strong>${ticketId}</strong> is now <strong>In Progress</strong>.`, null, 'fa-spinner', ticket.createdBy);
    }
    closeModal();
    renderTickets();
    showToast('Ticket status updated', 'success');
  }
}

function deleteTicket(ticketId) {
  if (!currentUser || currentUser.role !== 'admin') { showToast('Admin access required', 'error'); return; }
  if (!confirm('Delete this ticket?')) return;
  let tickets = getData('etg_tickets') || [];
  tickets = tickets.filter(t => t.ticketId !== ticketId);
  setData('etg_tickets', tickets);
  renderTickets();
  showToast('Ticket deleted', 'success');
}
