/* =============================================
   ETG TRAVELS — Purchases Module
   ============================================= */

const PURCHASE_SERVICES = ['VFS Fee', 'ODMC Fee', 'Other'];

function renderPurchases() {
  const purchases = getData('etg_purchases') || [];
  let rows = '';
  if (purchases.length === 0) {
    rows = '<div class="no-data"><i class="fa-solid fa-cart-shopping"></i><p>No purchases yet. Add your first purchase!</p></div>';
  } else {
    rows = `<div class="table-container"><table><thead><tr>
      <th>ID</th><th>Vendor</th><th>Date</th><th>Service</th><th>Amount</th><th>Paid By</th><th>Actions</th>
    </tr></thead><tbody>${purchases.map(p => {
      const svcLabel = p.service === 'Other' ? (p.serviceOther || 'Other') : p.service;
      const accColor = p.paidBy === 'Company Account' ? 'badge-info' : p.paidBy === 'Sujith Account' ? 'badge-success' : 'badge-warning';
      return `<tr>
        <td><span class="badge badge-gold">PUR-${p.id}</span></td>
        <td>${p.vendorName}</td>
        <td>${p.date}</td>
        <td>${svcLabel}</td>
        <td>₹${parseFloat(p.amount).toLocaleString('en-IN')}</td>
        <td><span class="badge ${accColor}">${p.paidBy}</span></td>
        <td>
          <button class="btn-icon" onclick="editPurchase(${p.id})"><i class="fa-solid fa-pen"></i></button>
          <button class="btn-icon" onclick="deletePurchase(${p.id})" style="margin-left:4px;"><i class="fa-solid fa-trash"></i></button>
        </td>
      </tr>`;
    }).join('')}</tbody></table></div>`;
  }

  const totalSpent = purchases.reduce((s, p) => s + (parseFloat(p.amount) || 0), 0);

  document.getElementById('purchasesContent').innerHTML = `
    <div class="stats-grid">
      <div class="stat-card"><div class="stat-icon red"><i class="fa-solid fa-cart-shopping"></i></div><div class="stat-info"><h4>${purchases.length}</h4><p>Total Purchases</p></div></div>
      <div class="stat-card"><div class="stat-icon gold"><i class="fa-solid fa-indian-rupee-sign"></i></div><div class="stat-info"><h4>₹${totalSpent.toLocaleString('en-IN')}</h4><p>Total Spent</p></div></div>
    </div>
    <div class="card">
      <div class="card-header">
        <h3><i class="fa-solid fa-cart-shopping"></i> All Purchases</h3>
        <button class="btn btn-gold btn-sm" onclick="openPurchaseModal()"><i class="fa-solid fa-plus"></i> New Purchase</button>
      </div>${rows}
    </div>`;
}

function openPurchaseModal(purchase) {
  const isEdit = !!purchase;
  const accOpts = ACCOUNTS_LIST.map(a => `<option value="${a}" ${purchase&&purchase.paidBy===a?'selected':''}>${a}</option>`).join('');
  const svcOpts = PURCHASE_SERVICES.map(s => `<option value="${s}" ${purchase&&purchase.service===s?'selected':''}>${s}</option>`).join('');
  const showOther = purchase && purchase.service === 'Other';

  openModal(isEdit ? 'Edit Purchase' : 'New Purchase', `
    <div class="form-grid">
      <div class="form-group-app"><label>Vendor Name *</label><input type="text" id="purVendor" value="${purchase?purchase.vendorName:''}"></div>
      <div class="form-group-app"><label>Date</label><input type="date" id="purDate" value="${purchase?purchase.date:new Date().toISOString().split('T')[0]}"></div>
    </div>
    <div class="form-grid mt-16">
      <div class="form-group-app"><label>Service *</label>
        <select id="purService" onchange="togglePurchaseOther()">
          <option value="">-- Select Service --</option>${svcOpts}
        </select>
      </div>
      <div class="form-group-app" id="purOtherSection" style="display:${showOther?'block':'none'};">
        <label>Specify Service</label>
        <input type="text" id="purServiceOther" value="${purchase&&purchase.serviceOther?purchase.serviceOther:''}" placeholder="Enter service name">
      </div>
    </div>
    <div class="form-grid mt-16">
      <div class="form-group-app"><label>Amount (₹) *</label><input type="number" id="purAmount" value="${purchase?purchase.amount:'0'}" min="0"></div>
      <div class="form-group-app"><label>Paid By *</label>
        <select id="purPaidBy"><option value="">-- Select Account --</option>${accOpts}</select>
      </div>
    </div>
    <button class="btn btn-gold w-full mt-16" onclick="${isEdit?`saveEditPurchase(${purchase.id})`:'savePurchase()'}">
      <i class="fa-solid fa-save"></i> ${isEdit?'Update':'Save'} Purchase
    </button>`);
}

function togglePurchaseOther() {
  const svc = document.getElementById('purService').value;
  document.getElementById('purOtherSection').style.display = svc === 'Other' ? 'block' : 'none';
}

function savePurchase() {
  const vendor = document.getElementById('purVendor').value.trim();
  const service = document.getElementById('purService').value;
  const amount = document.getElementById('purAmount').value;
  const paidBy = document.getElementById('purPaidBy').value;
  if (!vendor) { showToast('Vendor name is required', 'error'); return; }
  if (!service) { showToast('Please select a service', 'error'); return; }
  if (!paidBy) { showToast('Please select the paying account', 'error'); return; }
  if (!amount || parseFloat(amount) <= 0) { showToast('Enter a valid amount', 'error'); return; }

  const purchases = getData('etg_purchases') || [];
  const id = Date.now();
  purchases.push({
    id, vendorName: vendor, date: document.getElementById('purDate').value,
    service, serviceOther: service === 'Other' ? document.getElementById('purServiceOther').value.trim() : '',
    amount, paidBy
  });
  setData('etg_purchases', purchases);
  closeModal(); renderPurchases(); showToast('Purchase saved!', 'success');
}

function editPurchase(id) {
  const p = (getData('etg_purchases')||[]).find(x => x.id === id);
  if (p) openPurchaseModal(p);
}

function saveEditPurchase(id) {
  const purchases = getData('etg_purchases') || [];
  const idx = purchases.findIndex(p => p.id === id);
  if (idx === -1) return;
  const vendor = document.getElementById('purVendor').value.trim();
  const service = document.getElementById('purService').value;
  const amount = document.getElementById('purAmount').value;
  const paidBy = document.getElementById('purPaidBy').value;
  if (!vendor) { showToast('Vendor name is required', 'error'); return; }
  if (!service) { showToast('Please select a service', 'error'); return; }
  if (!paidBy) { showToast('Please select the paying account', 'error'); return; }

  purchases[idx] = { ...purchases[idx], vendorName: vendor, date: document.getElementById('purDate').value,
    service, serviceOther: service === 'Other' ? document.getElementById('purServiceOther').value.trim() : '',
    amount, paidBy };
  setData('etg_purchases', purchases);
  closeModal(); renderPurchases(); showToast('Purchase updated!', 'success');
}

function deletePurchase(id) {
  if (!confirm('Delete this purchase?')) return;
  let purchases = getData('etg_purchases') || [];
  purchases = purchases.filter(p => p.id !== id);
  setData('etg_purchases', purchases);
  renderPurchases(); showToast('Purchase deleted', 'success');
}
